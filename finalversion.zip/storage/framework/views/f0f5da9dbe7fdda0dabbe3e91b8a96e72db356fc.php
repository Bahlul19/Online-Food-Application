<?php $__env->startSection('title'); ?>
    Test Of some js code in our website
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <input type="text" id="nwInput">
    <button type="button" id="myButton">Click Here</button>
    <p style="color:red" id="inputShow"></p>

<?php $__env->stopSection(); ?>



<!-- <script>
function filterProducts() {
    var price_range = $('.price_range').val();
    $.ajax({
        type: 'POST',
        url: 'getProducts.php',
        data:'price_range='+price_range,
        beforeSend: function () {
            $('.container').css("opacity", ".5");
        },
        success: function (html) {
            $('#productContainer').html(html);
            $('.container').css("opacity", "");
        }
    });
}
</script> -->
<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>