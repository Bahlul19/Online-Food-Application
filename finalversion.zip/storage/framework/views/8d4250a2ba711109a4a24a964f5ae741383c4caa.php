<?php $__env->startSection('title'); ?>
    FoodItem Page Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">


            <form action="<?php echo e(action('FoodItemController@getFoodItemEditSave')); ?>" method="get" enctype="multipart/form-data"><!--Form Start-->

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="fooditemID" value="<?php echo e($table->foodItemID); ?>">


                <select name="restaurantID" class="form-control">

                    <?php foreach($restaurant as $row): ?>


                        <option value="<?php echo e($row->restaurantID); ?>"><?php echo e($row->restaurantName); ?></option>

                    <?php endforeach; ?>

                </select>

                <br/>

                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Food Name:</span>

                    <input type="text" name="foodName" class="form-control" value="<?php echo e($table->foodName); ?>">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>

                <br/>

                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Food Description:</span>

                    <input type="text" name="foodDescription" class="form-control" value="<?php echo e($table->foodDescription); ?>">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>
                <br/>


                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Food Price:</span>

                    <input type="text" name="price" class="form-control" value="<?php echo e($table->price); ?>">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>
                <br/>



                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Food Tag:</span>

                    <input type="text" name="foodTag" class="form-control" value="<?php echo e($table->foodTag); ?>">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>

                <br/>

                <button type="button" class="btn btn-default pull-left" >Close</button>
                <button type="submit" class="btn btn-info btn-sm pull-right">Update</button>



            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>