
<div class="container-fluid">
<form id="myForm" action="<?php echo e(action('usercityPage@getSearch')); ?>" method="get" enctype="multipart/form-data">
    <input autocomplete="on" type="text" name="name" placeholder="Search Here">
    <button type="submit">Search</button>
</form>


    <div id="showRequest" style="height: 400px; width: 800px; overflow: auto" >
        <ul>

        </ul>
    </div>
</div>