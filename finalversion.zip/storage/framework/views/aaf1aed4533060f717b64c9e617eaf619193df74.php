<?php $__env->startSection('title'); ?>
    Online Food Apps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-3"></div>
			<div class="col-md-6">
				<form action="" method="get" enctype="multipart/form-data" title="Order Details">
                	<div class="input-group has-warning has-feedback">

                    	<span class="input-group-addon" id="basic-addon1">Food Name:</span>

                    	<input type="text" name="foodName" class="form-control" value="">

                    	<span class="glyphicon glyphicon-tower form-control-feedback"></span>

                	</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>