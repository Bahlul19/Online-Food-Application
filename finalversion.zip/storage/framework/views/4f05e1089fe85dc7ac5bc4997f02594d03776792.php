<?php $__env->startSection('title'); ?>
    term
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- breadcrumb -->  
	<div class="container">	
		<ol class="breadcrumb w3l-crumbs">
			<li><a href="#"><i class="fa fa-home"></i> Home</a></li> 
			<li class="active">Terms & Conditions</li>
		</ol>
	</div>
	<!-- //breadcrumb -->

    <?php echo $__env->make('onlineUser.userpageparts.term', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermasterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>