<!--SideBar Section-->

<div class="col-md-2 col-sm-1 hidden-xs  display-table-cell valign-top" id="side-menu">
    <?php /*<h1 class="hidden-sm hidden-xs">Nevigation</h1>*/ ?>
    <h1 class="hidden-sm hidden-xs">Admin</h1>
    <ul>


        <!--for Dashboard-->
        <li class="link <?php echo e((Request::is('/') ? 'active' : '')); ?>">
            <a href="<?php echo e(url('/')); ?>">
                <span class="  glyphicon glyphicon-home" aria-hidden="true"></span>
                <span class="hidden-xs hidden-sm">Dashboard</span>
            </a>
        </li>


        <!--for Area-->
        <li class="link <?php echo e((Request::is('areapage') ? 'active' : '')); ?>">
            <a href="<?php echo e(url('areapage')); ?>">
                <span class="glyphicon glyphicon-tower" aria-hidden="true"></span>
                <span class="hidden-sm hidden-xs">Area</span>
            </a>
        </li>



        <!--for Restaurant-->
        <li class="link  <?php echo e((Request::is('restaurantpage') ? 'active' : '')); ?>">
            <a href="<?php echo e(url('restaurantpage')); ?>">
                <span class="glyphicon glyphicon-king" aria-hidden="true"></span>
                <span class="hidden-sm hidden-xs">Restaurant</span>
            </a>
        </li>



        <!--for FoodItem-->

        <li class="link  <?php echo e((Request::is('fooditempage') ? 'active' : '')); ?> ">
            <a href="<?php echo e(url('fooditempage')); ?>">
                <span class="glyphicon glyphicon-cutlery" aria-hidden="true"></span>
                <span class="hidden-sm hidden-xs">Food Item</span>
            </a>
        </li>



    </ul>
</div>