<?php $__env->startSection('title'); ?>
    FoodItem Page Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        
        <div class="col-md-6">


            <form action="" method="get" enctype="multipart/form-data"><!--Form Start-->

                <?php echo e(csrf_field()); ?><!-- <?php echo e(action('FoodItemController@getFoodItemEditSave')); ?>-->



                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Payment:</span>

                    <input type="text" name="foodName" class="form-control" value="">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>

                <br/>

                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Address:</span>

                    <input type="text" name="foodDescription" class="form-control" value="">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>
                <br/>


                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Mobile:</span>

                    <input type="text" name="price" class="form-control" value="">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>
                <br/>



                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Massage:</span>

                    <input type="text" name="foodTag" class="form-control" value="">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>

                <br/>

            </form>
                  <!--food items-->

            <div class="col-md-12" >
                <table class="table table-bordered table-striped ">
                    <thead >
                        <tr>
                            <th>FoodItem Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>   
                            <td></td>
                        </tr>
                            <td colspan="2" style="text-align: right;">Larry the Bird</td>
                            <td></td>
                    </tbody>    
                </table>
            </div>
            <!--food items-->
            <button type="button" class="btn btn-default pull-left" >Back</button
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>