<?php $__env->startSection('title'); ?>
    Online Food Apps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
<div class="container-fluid">
	<h3>this is Order contant</h3>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-10">
			<table class="table table-bordered table-striped ">
				<thead>
					<tr>
						<th>Order ID</th>
						<th>FoodItem</th>
						<th>RestaurantName</th>
						<th>Order status</th>
						<th>Payment status</th>
						<th>Customer Name</th>
						<th>Approve</th>
						<th>Cancel</th>
						<th>Details</th>
					</tr>
				</thead>

				<tbody>
				<?php foreach($table as $row): ?>
					<tr>
						<td><?php echo e($row->orderID); ?></td>
						<td><?php echo e($row->foodName); ?> </td>	
						<td><?php echo e($row->restaurantName); ?></td>
						<td>Delivering</td>
						<td><?php echo e($row->payment); ?></td>
						<td><?php echo e($row->customerName); ?></td>
						<td>
                            <a class="btn btn-success" href="">
                                <span class="glyphicon glyphicon-ok"></span>
                            </a>
						</td>
						<td>
							<a class="btn btn-danger" href="">
                                <span class="glyphicon glyphicon-remove"></span>
                            </a>
						</td>
						<td>
							<a class="btn btn-primary" href="<?php echo e(url('orderdetails')); ?>">
                               More
                            </a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>