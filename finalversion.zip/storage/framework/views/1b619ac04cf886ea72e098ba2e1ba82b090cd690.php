<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <link href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/default.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>

<div class="container-fluid display-table">


    <div class="row display-table-row">

        <?php echo $__env->make('shared.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-md-10 col-sm-11 box display-table-cell valign-top">
            <?php echo $__env->make('shared.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="upbtn"><?php echo $__env->yieldContent('svbutn'); ?>
                    </div>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>


            <?php echo $__env->make('shared.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        </div>

    </div>

</div>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->yieldContent('box'); ?>
        </div>
    </div>
</div>



<script type="text/javascript" src="<?php echo e(asset('public/js/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/js/default.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>