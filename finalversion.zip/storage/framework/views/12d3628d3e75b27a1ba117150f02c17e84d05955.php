<?php $__env->startSection('title'); ?>
    Online Food Apps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-2">
                <a class="btn btn-primary" href="<?php echo e(url('/')); ?>"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> Back</a>
            </div>
            <div class="col-md-10">
                <h3>Order item list (Order ID: <?php echo e($id); ?>)</h3>

                <table class="table table-bordered table-striped ">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Food Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <?php /*<th>Restaurant Name</th>*/ ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 0; ?>
                    <?php foreach($table as $row): ?>
                        <tr>
                            <td><?php echo e($row->orderItemID); ?></td>
                            <td><?php echo e($row->foodItem['foodName']); ?></td>
                            <td><?php echo e($row->quantity); ?></td>
                            <td><?php echo e($row->foodItem['price']*$row->quantity); ?></td>
                            <?php /*<td><?php echo e($row->restaurant['restaurantName']); ?></td>*/ ?>

                        </tr>
                        <?php
                        $value = ($row->foodItem['price'] * $row->quantity);
                        $i += $value;
                        ?>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3" style="text-align: right; font-weight: bold;">Total Amount</td>
                        <td><?php echo e(floor($i)); ?></td>
                    </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>