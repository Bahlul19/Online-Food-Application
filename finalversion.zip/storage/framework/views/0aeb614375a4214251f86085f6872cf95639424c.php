<?php $__env->startSection('title'); ?>
    Online Food Apps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <h3>This is our main page</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>