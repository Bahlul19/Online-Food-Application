<?php $__env->startSection('title'); ?>

    Food Item Section

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid"><!--Container-fluid Div Start-->

   <div class="row"><!--First Row Of The Div Start-->

       <div class="col-md-6"><!--For Button Restaurant Start-->


           <button type="button" class="btn btn-primary fooditemBox" data-target="#FoodItemBox" data-toggle="modal">
               <span class="glyphicon glyphicon-plus"></span> New Food Item Entry
           </button>

       </div><!--For Button Restaurant End-->

       <div class="col-md-6"><!--For Flash Message Start-->
           <?php if(session('status')): ?>

               <div class="alert alert-success alert-dismissible fade in" role="alert">
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                       <span aria-hidden="true">&times;</span></button><?php echo e(session('status')); ?>

               </div>

           <?php endif; ?>
       </div><!--For Flash Message End-->

   </div><!--First Row Of The Div End-->

    <div class="row"><!--Second Row Of The Div Start-->


      <div class="col-md-2"></div>

        <div class="col-md-10">


            <table class="table table-bordered table-striped">

                <thead>
                <tr>
                    <th>Food Item ID</th>
                    <th>Food Name</th>
                    <th>Food Description</th>
                    <th>Price</th>
                    <th>Food Tag</th>
                    <?php /*<th>Restaurant ID</th>*/ ?>
                    <th>Restaurant Name</th>
                    <th>Remove</th>
                    <th>Update</th>
                </tr>
                </thead>

                <tbody>

                <?php foreach($table as $row): ?>

                    <tr>
                        <td><?php echo e($row->foodItemID); ?></td>
                        <td><?php echo e($row->foodName); ?></td>
                        <td><?php echo e($row->foodDescription); ?></td>
                        <td><?php echo e($row->price); ?></td>
                        <td><?php echo e($row->foodTag); ?></td>
                        <?php /*<td><?php echo e($row->restaurantID); ?></td>*/ ?>
                        <td><?php echo e($row->restaurant['restaurantName']); ?></td>


                        <td>
                            <a class="btn btn-danger" href="<?php echo e(action('FoodItemController@getFoodItemDel',['id'=>$row->foodItemID])); ?>">
                                <span class="glyphicon glyphicon-remove"></span>
                            </a> </td>
                        <td><a class="btn btn-info" href="<?php echo e(action('FoodItemController@getFoodItemEdit',['id'=>$row->foodItemID])); ?>">
                                <span class=" glyphicon glyphicon-pencil"></span>
                            </a></td>
                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>
            <div><?php echo e($table->links()); ?></div>


        </div>

    </div><!--Second Row Of The Div End-->
</div><!--Container-Fluid Div End-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('shared.box.fooditemBox', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>