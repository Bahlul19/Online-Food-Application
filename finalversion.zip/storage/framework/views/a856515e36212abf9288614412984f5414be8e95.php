<?php $__env->startSection('title'); ?>
    Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- breadcrumb -->  
	<div class="container">	
		<ol class="breadcrumb w3l-crumbs">
			<li><a href="#"><i class="fa fa-home"></i> Home</a></li> 
			<li class="active">Order</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
		<div class="login-page about">
		<img class="login-w3img" src="public/userassets/images/img3.jpg" alt="">
		<div class="container">
		  <h2 style="color:#12cae2;margin-left:200px;">Order your FoodItems</h2><br>
		  <form class="form-horizontal" action="" method="" enctype="">
		  <!--start information-->
		  	<div class="form-group">
		      <label class="control-label col-sm-2" for="email">Name:</label>
		      <div class="col-sm-10" style="width: 500px">
		        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email"required="">
		      </div>
		    </div><br>

		    <div class="form-group">
		      <label class="control-label col-sm-2" for="email">Mobile:</label>
		      <div class="col-sm-10" style="width: 500px">
		        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email"required="">
		      </div>
		    </div><br>
		    <div class="form-group">
		      <label class="control-label col-sm-2" for="email">Address:</label>
		      <div class="col-sm-10" style="width: 500px">
		        <input type="email" class="form-control" id="email" placeholder="Enter your address" name="email"required="">
		      </div>
		    </div><br>

		    <div class="form-group">
		      <label class="control-label col-sm-2" for="email">Massage:</label>
		      <div class="col-sm-10" style="width: 500px">
		        <input type="email" class="form-control" id="email" placeholder="Enter your massage" name="email"required="">
		        	
		      </div>
		    </div><br><!--end information-->
             <!--fooditems-->
             <h3 style="text-align: center;">All Orders Items</h3><br>

		    <div class="col-md-6" >
		    	<table class="table table-bordered table-striped " style="margin-left: 110px">
		    		<thead >
						<tr>
							<th>FoodItem Name</th>
							<th>Quantity</th>
							<th>Price</th>
						</tr>
					</thead>

					<tbody>
						<tr>
							<td></td>
							<td></td>	
							<td></td>
						</tr>
					</tbody>	
		    	</table>
		    </div>

		    <div class="form-group">        
		      <div class="col-sm-offset-2 col-sm-10" >
		        <button type="submit" class="btn btn-success" style="background-color:#12cae2;margin-left: 370px; width: 100px;">Submit</button>
		      </div>
		      
		    </div>
		    <p style="color: red; font-size:25px;">Payment : Cash in delivary</p>
		  </form>
		  

		</div>

	</div>
	<!-- //sign up-page -->

    

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermasterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>