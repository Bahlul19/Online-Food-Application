<?php $__env->startSection('title'); ?>
    city
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- breadcrumb -->  
	<div class="container">	
		<ol class="breadcrumb w3l-crumbs">
			<li><a href="#"><i class="fa fa-home"></i> Home</a></li> 
			<li class="active">Dishes</li>
		</ol>
	</div>
	<!-- //breadcrumb -->

    <?php echo $__env->make('onlineUser.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('onlineUser.underproduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('onlineUser.dishes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('onlineUser.model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


	<!-- the jScrollPane script -->
	
	<script type="text/javascript" id="sourcecode">
		$(function()
		{
			$('.scroll-pane').jScrollPane();
		});
	</script>
	<!-- //the jScrollPane script -->

	<!-- Owl-Carousel-JavaScript -->
	
	<script>
		$(document).ready(function() {
			$("#owl-demo").owlCarousel ({
				items : 3,
				lazyLoad : true,
				autoPlay : true,
				pagination : true,
			});
		});
	</script>
	<!-- //Owl-Carousel-JavaScript -->
	<!--price filter script-->
					<script type="text/javascript">
							$('.price_range').jRange({
    							from: 0,
    							to: 500,
    							step: 1,
    							scale: [0,100,200,300,400,500],
    							format: '%s TK',
    							width: 250,
    							showLabels: true,
    							isRange : true
								});
					</script>
	<!--End price filter script-->
						
	<!-- script for tabs -->						
	<script type="text/javascript">
							$(function() {
							
								var menu_ul = $('.faq > li > ul'),
									   menu_a  = $('.faq > li > a');
								
								menu_ul.hide();
							
								menu_a.click(function(e) {
									e.preventDefault();
									if(!$(this).hasClass('active')) {
										menu_a.removeClass('active');
										menu_ul.filter(':visible').slideUp('normal');
										$(this).addClass('active').next().stop(true,true).slideDown('normal');
									} else {
										$(this).removeClass('active');
										$(this).next().stop(true,true).slideUp('normal');
									}
								});
							
							});
						</script>
						<!-- script for tabs -->





    <!-- smooth-scrolling-of-move-up -->
    <script type="text/javascript">
        $(document).ready(function() {
            /*
            var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
            };
            */
            
            $().UItoTop({ easingType: 'easeOutQuart' });
            
        });
    </script>
    <!-- //smooth-scrolling-of-move-up -->

    <script type="text/javascript">
        
    $(function () {

        $('.moredescriptions').on('click', function (e) {
        //e.preventDefault();

        var urls = $(this).data('url');

        $.ajax({
        url: urls,
        type: 'get',
        dataType: 'json',
        data: $(this).serialize(),
        success:function(result){
        	$('#item_name').html(result.foodname);
        	$('#Imagesview').attr('src', 'public/productImage/'+result.foodItemID+'.jpg');
        	$('#price').html(result.foodprice);
        	$('#description').html(result.fooddescription);
        	$('#Restaurantname').html(result.restaurantname);
       		$('#Areaname').html(result.areaname);

        //$('#myModal1').html(myRes);
        		}
       		});



     	});
      });
    </script>

  






<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.usermasterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>