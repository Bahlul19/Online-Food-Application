	<!-- subscribe -->
	<div class="subscribe agileits-w3layouts"> 
		<div class="container">
			<div class="col-md-6 social-icons w3-agile-icons">
				<h4>Keep in touch</h4>  
				<ul>
					<li><a href="#" class="fa fa-facebook icon facebook"> </a></li>
					<?php /*<li><a href="#" class="fa fa-twitter icon twitter"> </a></li>*/ ?>
					<li><a href="#" class="fa fa-google-plus icon googleplus"> </a></li>
					<li><a href="#" class="fa fa-instagram icon instagram"></a> </li>
					<?php /*<li><a href="#" class="fa fa-dribbble icon dribbble"> </a></li>*/ ?>
					<?php /*<li><a href="#" class="fa fa-rss icon rss"> </a></li> */ ?>

				</ul> 
			</div> 
			<div class="col-md-6 subscribe-right">
					<h3 class="w3ls-title">Subscribe to Our <br><span> Youtube Channel</span></h3>
				<!--
				<form action="#" method="post"> 
					<input type="email" name="email" placeholder="Enter your Email..." required="">
					<input type="submit" value="Subscribe">
					<div class="clearfix"> </div> 
				</form>
				-->
				<img src="public/userassets/images/i1.png" class="sub-w3lsimg" alt=""/>
			</div>
			<div class="clearfix"> </div> 
		</div>
	</div>
	<!-- //subscribe --> 
	<!-- footer -->
	<div class="footer agileits-w3layouts">
		<div class="container">
			<div class="w3_footer_grids">
				<div class="col-xs-6 col-sm-3 footer-grids w3-agileits">
					<h3>company</h3>
					<ul>
						<li><a href="<?php echo e(url('userabout')); ?>">About Us</a></li>
						<li><a href="<?php echo e(url('contact')); ?>">Contact Us</a></li>  
						<li><a href="<?php echo e(url('usercareer')); ?>">Careers</a></li>  
						<li><a href="<?php echo e(url('userhelp')); ?>">Partner With Us</a></li>   
					</ul>
				</div> 
				<div class="col-xs-6 col-sm-3 footer-grids w3-agileits">
					<h3>help</h3>
					<ul>
						<li><a href="<?php echo e(url('userfaq')); ?>">FAQ</a></li> 
						<li><a href="<?php echo e(url('userlogin')); ?>">Returns</a></li>   
						<li><a href="<?php echo e(url('userlogin')); ?>">Order Status</a></li> 
						<li><a href="<?php echo e(url('userlogin')); ?>">Offers</a></li> 
					</ul>  
				</div>
				<div class="col-xs-6 col-sm-3 footer-grids w3-agileits">
					<h3>policy info</h3>
					<ul>  
						<li><a href="<?php echo e(url('terms')); ?>">Terms & Conditions</a></li>  
						<li><a href="<?php echo e(url('privacy')); ?>">Privacy Policy</a></li>
						<li><a href="<?php echo e(url('userlogin')); ?>">Return Policy</a></li> 
					</ul>   
				</div>
				<div class="col-xs-6 col-sm-3 footer-grids w3-agileits">
					<h3>Menu</h3> 
					<ul>
						<li><a href="<?php echo e(url('city')); ?>">All Day Menu</a></li> 
						<li><a href="<?php echo e(url('city')); ?>">Lunch</a></li>
						<li><a href="<?php echo e(url('city')); ?>">Dinner</a></li>
						<li><a href="<?php echo e(url('city')); ?>">Flavours</a></li>
					</ul>  
				</div> 
				<div class="clearfix"> </div>
			</div>
		</div> 
	</div>
	<div class="copyw3-agile"> 
		<div class="container">
			<p>&copy; 2017 Our Foods. All rights reserved</p>
		</div>
	</div>
	<!-- //footer --> 