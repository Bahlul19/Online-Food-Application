<?php $__env->startSection('title'); ?>
    Restaurant Page Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">


            <form action="<?php echo e(action('RestaurantController@getRestaurantEditSave')); ?>" method="get" enctype="multipart/form-data"><!--Form Start-->

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="restaurantID" value="<?php echo e($table->restaurantID); ?>">


                    <select name="areaID" class="form-control">

                    <?php foreach($area as $row): ?>


                      <option value="<?php echo e($row->areaID); ?>"><?php echo e($row->areaName); ?></option>

                    <?php endforeach; ?>

                   </select>
                  <br/>



                <div class="input-group has-warning has-feedback">

                    <span class="input-group-addon" id="basic-addon1">Area Name:</span>

                    <input type="text" name="restaurantName" class="form-control" value="<?php echo e($table->restaurantName); ?>">

                    <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                </div>

                <br/>

                <button type="button" class="btn btn-default ">Close</button>
                <button type="submit" class="btn btn-info btn-sm">Update</button>



            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>