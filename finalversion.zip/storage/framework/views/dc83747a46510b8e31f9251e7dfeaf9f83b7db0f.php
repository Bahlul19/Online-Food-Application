<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html" />
    

    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/font-awesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/owl.carousel.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/style.css')); ?>" />



    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/fonts.googleapis.com/css?family=Berkshire+Swash')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('public/Newfolder/css/fonts.googleapis.com/css?family=Yantramanav:100,300,400,500,700,900')); ?>" />
    <?php echo $__env->yieldContent('style'); ?>

</head>
<body>
    
        <div>
            <?php echo $__env->make('onlineUser.userpageparts.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>


        <div>
            <?php echo $__env->make('onlineUser.userpageparts.sfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    
<script src="<?php echo e(asset('public/js/Newfolder/minicart.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/Newfolder/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/Newfolder/SmoothScroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/Newfolder/move-top.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/Newfolder/easing.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/Newfolder/jquery-2.2.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/Newfolder/js/bootstrap.js')); ?>"></script>

<script src="<?php echo e(asset('public/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>