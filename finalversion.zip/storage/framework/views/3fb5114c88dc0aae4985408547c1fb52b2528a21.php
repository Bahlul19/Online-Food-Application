<?php $__env->startSection('title'); ?>
    Online Food Apps
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
<div class="container-fluid">

	<div class="row">
		<div class="col-md-12">
			<h3>Order list</h3>
			<table class="table table-bordered table-striped ">
				<thead>
					<tr>
						<th>OrderID</th>
						<th>Date</th>
						<th>Customer Name</th>
						<th>Address</th>
						<th>Contact No</th>
						<th>Comments</th>
						<th>Payment</th>
						<th>Status</th>
						<th>Approve</th>
						<th>Cancel</th>
						<th>Details</th>
						<th style="text-align: right;">Delete</th>
					</tr>
				</thead>

				<tbody>
				<?php foreach($table as $row): ?>
					<tr>
						<td><?php echo e($row->orderID); ?></td>
						<td><?php echo e(date('d/m/Y', strtotime($row->created_at))); ?></td>
						<td><?php echo e($row->customer['customerName']); ?></td>
						<td><?php echo e($row->customer['customerAddress']); ?> </td>
						<td><?php echo e($row->customer['customerNumber']); ?></td>
						<td><?php echo e($row->customerMessage); ?></td>
						<td><?php echo e($row->payment); ?></td>
						<td><?php echo e($row->orderStatus); ?></td>

						<td>
                            <a class="btn btn-success" href="<?php echo e(action('userorderController@order_approve', [$row->orderID])); ?>">
                                <span class="glyphicon glyphicon-ok"></span>
                            </a>
						</td>
						<td>
							<a class="btn btn-danger" href="<?php echo e(action('userorderController@order_cancel', [$row->orderID])); ?>">
                                <span class="glyphicon glyphicon-remove"></span>
                            </a>
						</td>
						<td>
							<a class="btn btn-primary" href="<?php echo e(action('userorderController@order_view', [$row->orderID])); ?>">
                               More
                            </a>
						</td>
						<td>
							<a class="close" href="<?php echo e(action('userorderController@order_del', [$row->orderID])); ?>">
								<span aria-hidden="true">&times;</span>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>