<?php $__env->startSection('title'); ?>
    Area Page Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">


            <form action="<?php echo e(action('AreaController@getAreaEditSave')); ?>" method="get" enctype="multipart/form-data"><!--Form Start-->

                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="areaID" value="<?php echo e($table->areaID); ?>">
                    <div class="input-group has-warning has-feedback">

                        <span class="input-group-addon" id="basic-addon1">Area Name:</span>

                        <input type="text" name="areaName" class="form-control" value="<?php echo e($table->areaName); ?>">

                        <span class="glyphicon glyphicon-tower form-control-feedback"></span>

                    </div>

                <br/>

                    <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
                    <button type="submit" class="btn btn-info btn-sm">Update</button>



       </form>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>