<?php $__env->startSection('title'); ?>
   Our Foods
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   
    <?php echo $__env->make('onlineUser.orders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('onlineUser.deals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('onlineUser.dishes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
        <!-- Owl-Carousel-JavaScript -->
    <script src="js/owl.carousel.js"></script>
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel ({
                items : 3,
                lazyLoad : true,
                autoPlay : true,
                pagination : true,
            });
        });
    </script>
    <!-- //Owl-Carousel-JavaScript --> 

	


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.usermasterPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>