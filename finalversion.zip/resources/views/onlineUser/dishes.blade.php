<!-- dishes -->
<div class="w3agile-spldishes">
	<div class="container">
		<h3 class="w3ls-title">Special Foods</h3>
		<div class="spldishes-agileinfo">
			<div class="col-md-3 spldishes-w3left">
				<h5 class="w3ltitle">Special dishes</h5>

				<p>Special food makes our taste special and make us to feel the food inside mouth</p>
			</div>
			<div class="col-md-9 spldishes-grids">
				<!-- Owl-Carousel -->
				<div id="owl-demo" class="owl-carousel text-center agileinfo-gallery-row">
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g1.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g2.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g3.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g4.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g5.jpg" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g1.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}" class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g2.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
					<a href="{{url('city')}}"class="item g1">
						<img class="lazyOwl" src="public/userassets/images/g3.jpg" title="Our latest gallery" alt=""/>
						<div class="agile-dish-caption">
							<h4>Special Food</h4>
							<span>Enjoy every bite of food </span>
						</div>
					</a>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!-- //dishes -->