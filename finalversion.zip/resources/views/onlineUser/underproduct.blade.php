<div class="container"> 
	<div class="w3agile-deals prds-w3text"> 
		<h5>Vestibulum maximus quam et quam egestas imperdiet. In dignissim auctor viverra.</h5>
	</div>
</div>