<!-- deals -->
<div class="w3agile-deals">
	<div class="container">
		<h3 class="w3ls-title">Special Services</h3>
		<div class="dealsrow">
			<div class="col-md-6 col-sm-6 deals-grids">
				<div class="deals-left">
					<i class="fa fa-truck" aria-hidden="true"></i>
				</div>
				<div class="deals-right">
					<h4>FREE DELIVERY</h4>
					<p>We have free home delivery services, Please Call Us: 01731691994 or 01705239677 </p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 col-sm-6 deals-grids">
				<div class="deals-left">
					<i class="fa fa-birthday-cake" aria-hidden="true"></i>
				</div>
				<div class="deals-right">
					<h4>Party Orders</h4>

					<p>For party orders please visit our office, Rongmohol Tower, 9th Floor, Bondor Bazar </p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 col-sm-6 deals-grids">
				<div class="deals-left">
					<i class="fa fa-users" aria-hidden="true"></i>
				</div>
				<div class="deals-right">
					<h4>Team up Scheme</h4>
					<p>We are students and we bulid this application for own city Sylhet to give them well and
						good food services</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 col-sm-6 deals-grids">
				<div class="deals-left">
					<i class="fa fa-building" aria-hidden="true"></i>
				</div>
				<div class="deals-right">
					<h4>corporate orders</h4>
					<p>We take corporate orders, please visit our office, Rongmohol Tower, 9th Floor, Bondor Bazar </p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!-- //deals -->