<!--Footer Section-->


<div class="row">
    <footer id="admin-footer" class="clearfix">
        <div class="pull-left"><b>Copyright </b>&copy; 2017</div>
        <div class="pull-right">Created By Tausif and Fahmida</div>
    </footer>
</div>