@extends('layouts.masterPage')

@section('title')
    Test Of some js code in our website
@endsection

@section('content')

    <input type="text" id="nwInput">
    <button type="button" id="myButton">Click Here</button>
    <p style="color:red" id="inputShow"></p>

@endsection